---
title: 基础
weight: 5
pre: "<b>1. </b>"
chapter: true
---

### 章节 1

# 基础

了解该 Hugo 主题的特点以及背后的核心概念。
