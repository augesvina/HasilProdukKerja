export const CLASS_ERROR = "is-invalid";
export const ELEMENT_HELP_BLOCK = "div";
export const CLASS_HELP_BLOCK = "invalid-feedback";
export const SEPARATOR_RULE = "|";
export const SEPARATOR_OPTION = ":";
export const LISTENER = "input";
